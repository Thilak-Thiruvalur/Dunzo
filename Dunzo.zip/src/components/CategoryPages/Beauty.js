import React from 'react'
import Items from './Items'

export default function Beauty() {
  return (
    <div>
      <Items />
    </div>
  )
}
