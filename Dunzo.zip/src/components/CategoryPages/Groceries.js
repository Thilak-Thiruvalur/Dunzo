import React from 'react'
import Items from './Items'

export default function Groceries() {
  return (
    <div>
      <Items />
    </div>
  )
}
