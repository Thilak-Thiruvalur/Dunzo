import React from 'react'
import Items from './Items'

export default function Electronics() {
  return (
    <div>
      <Items />
    </div>
  )
}
