import React from 'react'
import Items from './Items'

export default function Clothing() {
  return (
    <div>
      <Items />
    </div>
  )
}
